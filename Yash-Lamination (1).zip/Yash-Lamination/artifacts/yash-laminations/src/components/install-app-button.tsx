import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

type InstallAppButtonProps = {
  compact?: boolean;
};

function isRunningAsInstalledApp() {
  const isStandalone = window.matchMedia("(display-mode: standalone)").matches;
  const isIosStandalone =
    "standalone" in navigator &&
    Boolean((navigator as Navigator & { standalone?: boolean }).standalone);

  return isStandalone || isIosStandalone;
}

function getInstallInstructions() {
  const isIos =
    /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

  if (isIos) {
    return [
      "Open this page in Safari.",
      "Tap the Share button.",
      'Choose "Add to Home Screen", then tap "Add".',
    ];
  }

  if (/Android/i.test(navigator.userAgent)) {
    return [
      "Open this page in Chrome.",
      "Tap the browser menu (⋮).",
      'Choose "Install app" or "Add to Home screen".',
    ];
  }

  return [
    "Open this page in Chrome or Edge.",
    "Select the install icon in the address bar or open the browser menu.",
    'Choose "Install Yash Laminations".',
  ];
}

export function InstallAppButton({ compact = false }: InstallAppButtonProps) {
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [instructionsOpen, setInstructionsOpen] = useState(false);

  useEffect(() => {
    setIsInstalled(isRunningAsInstalledApp());

    const handleInstallAvailable = (event: Event) => {
      const installEvent = event as InstallPromptEvent;
      installEvent.preventDefault();
      setInstallPrompt(installEvent);
    };
    const handleInstalled = () => {
      setIsInstalled(true);
      setInstallPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handleInstallAvailable);
    window.addEventListener("appinstalled", handleInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleInstallAvailable);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  if (isInstalled) return null;

  const handleClick = async () => {
    if (!installPrompt) {
      setInstructionsOpen(true);
      return;
    }

    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    setInstallPrompt(null);
    if (choice.outcome === "accepted") setIsInstalled(true);
  };

  return (
    <>
      <Button
        type="button"
        size={compact ? "sm" : "default"}
        variant="outline"
        className="shrink-0 font-bold"
        onClick={handleClick}
      >
        <Download aria-hidden="true" />
        <span>{compact ? "Install" : "Install App"}</span>
      </Button>

      <Dialog open={instructionsOpen} onOpenChange={setInstructionsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Install Yash Laminations</DialogTitle>
            <DialogDescription>
              Add the site to your home screen to open it like an app.
            </DialogDescription>
          </DialogHeader>
          <ol className="list-decimal space-y-2 pl-5 text-sm text-foreground">
            {getInstallInstructions().map((instruction) => (
              <li key={instruction}>{instruction}</li>
            ))}
          </ol>
        </DialogContent>
      </Dialog>
    </>
  );
}